# Tutorial: How to Deploy Simply Static Post Process

Please read/watch detailed tutorial on [Seowings Tutorial Page](https://www.seowings.org/simply-static-tutorial/).