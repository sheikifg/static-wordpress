# StaticWordPressNetlify Class

::: src.main.StaticWordPressNetlify
